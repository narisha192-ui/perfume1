from django.shortcuts import render,redirect,HttpResponse
from.models import*
# Create your views here.
def index(request):
    return render(request,'index.html')

def about(request):
    return render(request,'index.html')
def buy_perfume(request):
    men_products=product.objects.filter(category='Men')
    return render(request,'buy-perfume.html',{'men_products':men_products})

def contact(request):
    if request.method=='POST':
        fname=request.POST['fname']
        lname=request.POST['lname']
        email=request.POST['email']
        message=request.POST['message']
        cnt(fname=fname,lname=lname,email=email,message=message).save()
        return HttpResponse("Your Message Sent!")
    return render(request,'contact.html')
def men(request):
    men_products=product.objects.filter(category='Men')
    return render(request,'men.html',{'men_products': men_products})
def women(request):
    women_products=product.objects.filter(category='Women')
    return render(request,'women.html',{'women_products':women_products})
def exclusive(request):
    exclusive_products=product.objects.filter(category='Exclusive')
    return render(request,'exclusive.html',{'exclusive_products':exclusive_products})
def exclusive1(request):
    return render(request,'exclusive1.html')
def cart(request):
    cart_items=CartItem.objects.filter(user=request.user)
    total_price=sum(item.product.price * item.quantity for item in cart_items)

    return render(request,'cart.html',{'cart_items':cart_items,'total_price':total_price})
def product_details(request,id):
    x=product.objects.get(id=id)
    if request.method=='POST':
        qty=int(request.POST['quantity'])
        
        y=CartItem(product=x,quantity=qty,user=request.user)
        y.save()
        return redirect(cart)
    return render(request,'product_details.html',{'x':x})


def delt(request,id):
    d=CartItem.objects.get(id=id,user=request.user)
    d.delete()
    return redirect(cart)


def checkout(request):
    cart_items = CartItem.objects.filter(user=request.user)
    total_price = sum(item.product.price * item.quantity for item in cart_items)

    if request.method == "POST":
        # You can process order here
        # e.g., save shipping info, clear cart, send email, etc.
        return redirect(thankyou)  # Create this page

    return render(request, 'checkout.html', {
        'cart_items': cart_items,
        'total_price': total_price
    })

def thankyou(request):
    if request.method == "POST":
        # Process order (save, clear cart, email, etc.)
        return redirect('thankyou')  # URL name for thankyou page
    return render(request,'thankyou.html')